package es.urjc.code.daw.library.unitary;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import es.urjc.code.daw.library.book.Book;
import es.urjc.code.daw.library.book.BookService;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("BookController REST tests - MockMVC")
public class BookRestControllerTest {

	@Autowired
	private MockMvc mvc;

	@Autowired
    private ObjectMapper objectMapper;
    
    @MockBean
    private BookService bookService;

	@Test
	@DisplayName("Comprobar que se pueden recuperar todos los libros (como usuario sin logear)")
	public void getBooksTest() throws Exception{

        List<Book> fakeBooks = Arrays.asList(new Book("FAKE BOOK 1","Contenido de prueba"), new Book("FAKE BOOK 2","Contenido de prueba"));

        when(bookService.findAll()).thenReturn(fakeBooks);

        mvc.perform(
			get("/api/books/")
				.contentType(MediaType.APPLICATION_JSON)
		  )
          .andExpect(status().isOk())
          .andExpect(jsonPath("$", hasSize(2)));
		
	}

	@Test
    @DisplayName("Añadir un nuevo libro (como usuario logeado)")
    @WithMockUser(username = "user", password = "pass", roles = "USER")
	public void createBookTest() throws Exception {

        Book book = new Book("FAKE BOOK","Contenido de prueba");

        when(bookService.save(any(Book.class))).thenReturn(book);
		
		mvc.perform(
            post("/api/books/")
				.content(objectMapper.writeValueAsString(book))
				.contentType(MediaType.APPLICATION_JSON)
          )
          .andExpect(status().isCreated())
          .andExpect(jsonPath("$.title", equalTo(book.getTitle())));
          
	}

	@Test
    @DisplayName("Borrar un libro (como administrador)")
    @WithMockUser(username = "admin", password = "pass", roles = "ADMIN")
	public void deleteBookTest() throws Exception {

        doNothing().when(bookService).delete(isA(Long.class));
		
		mvc.perform(
            delete("/api/books/1")
				.contentType(MediaType.APPLICATION_JSON)
          )
          .andExpect(status().isOk());

	}

}
