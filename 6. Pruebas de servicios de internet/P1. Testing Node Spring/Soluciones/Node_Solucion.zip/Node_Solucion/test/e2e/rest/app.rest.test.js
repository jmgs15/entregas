const app = require('../../../src/app');
const supertest = require('supertest');
const { GenericContainer } = require("testcontainers");
const createTableIfNotExist = require("../../../src/db/createTable")
const AWS= require('aws-sdk');

const request = supertest(app)

let dynamoContainer;

beforeAll(async () => {

    dynamoContainer = await new GenericContainer("amazon/dynamodb-local","1.13.6")
      .withExposedPorts(8000)
      .start();

    AWS.config.update({
        region: process.env.AWS_REGION || 'local',
        endpoint: 'http://localhost:'+ dynamoContainer.getMappedPort(8000),
        accessKeyId: "xxxxxx", // No es necesario poner nada aquí
        secretAccessKey: "xxxxxx" // No es necesario poner nada aquí
    });

    await createTableIfNotExist("films");
});

afterAll(async () => {
    await dynamoContainer.stop();
});

let film = {
    "title": "Pulp Fiction",
    "year" : 1994,
    "director": "Quentin Tarantino"
}

test('Create new film', async () => {

    const response = await request.post('/api/films/')
        .send(film)      
        .expect(201)

    expect(response.body.director).toBe(film.director)

})

test('Get all films', async () => {

    // await request.post('/api/films/').send({
    //     "title": "Scarface",
    //     "year" : 1983,
    //     "director": "Brian De Palma"
    // })

    const response = await request.get('/api/films/')
        .expect('Content-type', /json/)
        .expect(200)

    // expect(response.body).toEqual(
    //     expect.arrayContaining([
    //         expect.objectContaining({"title": "Scarface"})
    //     ])
    // );

})