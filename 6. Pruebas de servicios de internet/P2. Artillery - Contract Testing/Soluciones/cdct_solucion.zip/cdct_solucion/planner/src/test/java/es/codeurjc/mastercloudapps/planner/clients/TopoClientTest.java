package es.codeurjc.mastercloudapps.planner.clients;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.cloud.contract.stubrunner.spring.StubRunnerProperties.StubsMode;
import org.springframework.web.client.RestTemplate;

import es.codeurjc.mastercloudapps.planner.models.LandscapeResponse;

@SpringBootTest
@AutoConfigureStubRunner(
		ids={"es.codeurjc.mastercloudapps.reactive:toposervice:+:stubs:8080"},
		stubsMode = StubsMode.LOCAL)
public class TopoClientTest {
	
	@Test
	void verifyTopoService() {
		RestTemplate restTemplate = new RestTemplate();
		
		LandscapeResponse response = restTemplate.getForObject("http://localhost:8080/api/topographicdetails/tokyo", LandscapeResponse.class);
		
		assertEquals("Flat", response.getLandscape());
	}

}
