package es.codeurjc.mastercloudapps.topo;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import es.codeurjc.mastercloudapps.topo.controller.TopoController;
import es.codeurjc.mastercloudapps.topo.model.City;
import es.codeurjc.mastercloudapps.topo.service.TopoService;
import io.restassured.module.mockmvc.RestAssuredMockMvc;

@SpringBootTest
public class BaseCDC {

	@MockBean
	TopoService topoService;
	
	@Autowired
	TopoController controller;
	
	@BeforeEach
	public void setup() {
		
		Mockito
			.when(this.topoService.getCity("tokyo"))
			.thenReturn(new City("Tokyo", "Flat"));
		
		RestAssuredMockMvc.standaloneSetup(this.controller);
	}
}
