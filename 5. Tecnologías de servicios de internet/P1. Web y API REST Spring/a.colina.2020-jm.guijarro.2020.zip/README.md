# BOOKS API REST

You can find the API documentation in the following [link](http://localhost:8080/swagger-ui.html).
You have to run first the application.