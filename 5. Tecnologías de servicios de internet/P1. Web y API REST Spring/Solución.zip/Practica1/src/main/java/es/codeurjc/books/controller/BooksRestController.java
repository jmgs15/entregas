package es.codeurjc.books.controller;

import static org.springframework.web.servlet.support.ServletUriComponentsBuilder.fromCurrentRequest;

import java.net.URI;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;

import es.codeurjc.books.model.Book;
import es.codeurjc.books.model.Comment;
import es.codeurjc.books.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/books")
public class BooksRestController {
	
	@Autowired
	private BookService bookService;
	
	@Operation(summary = "Get a simplified list of books")
	@ApiResponses(value = {
		@ApiResponse(
			responseCode = "200",
			description = "List of books",
			content = { @Content(
				mediaType = "application/json",
				schema = @Schema(implementation=Book.Simplified.class)
			)}
		)
	})
	@JsonView(Book.Simplified.class)
	@GetMapping("/")
	public Collection<Book> getBooks() {
		return this.bookService.findAll();
	}
	
	@Operation(summary = "Get a book by its id")
	@ApiResponses({
		@ApiResponse(
			responseCode = "200",
			description = "Found the book",
			content = { @Content(
				mediaType = "application/json",
				schema = @Schema(implementation=Book.class)
			)}
		),
		@ApiResponse(
			responseCode = "404",
			description = "Book not found",
			content = @Content
		)
	})
	@GetMapping("/{id}")
	public ResponseEntity<Book> getBook(
			@Parameter(description = "id of book to be searched")
			@PathVariable Long id) {
		
		Book book = this.bookService.findById(id);
		if (book != null) {
			return ResponseEntity.ok(book);
		}
		return ResponseEntity.notFound().build();
	}
	
	@Operation(summary = "Create a new book")
	@ApiResponses({
		@ApiResponse(
			responseCode = "201",
			description = "Book created",
			content = { @Content(
				mediaType = "application/json",
				schema = @Schema(implementation=Book.class)
			)}
		)
	})
	@PostMapping("/")
	public ResponseEntity<Book> createBook(@RequestBody Book book) {
		
		this.bookService.save(book);
		
		URI location = fromCurrentRequest().path("/{id}").build(book.getId());
		
		return ResponseEntity.created(location).body(book);
	}
	
	@Operation(summary = "Create a new comment for a book")
	@ApiResponses({
		@ApiResponse(
			responseCode = "201",
			description = "Comment created",
			content = { @Content(
				mediaType = "application/json",
				schema = @Schema(implementation=Comment.class)
			)}
		),
		@ApiResponse(
			responseCode = "404",
			description = "Book not found",
			content = @Content
		)
	})
	@PostMapping("/{id}/comments/")
	public ResponseEntity<Comment> createComment(@RequestBody Comment comment,
			@Parameter(description = "id of book to add the comment to") @PathVariable Long id) {
		
		Book book = this.bookService.findById(id);
		if (book == null) {
			return ResponseEntity.notFound().build();
		}
		this.bookService.saveComment(comment, id);
		URI location = fromCurrentRequest().path("/{id}").build(comment.getId());
		return ResponseEntity.created(location).body(comment);
	}
	
	@Operation(summary = "Delete a comment")
	@ApiResponses(value = {
		@ApiResponse(
			responseCode = "200",
			description = "Comment deleted",
			content = { @Content(
				mediaType = "application/json",
				schema = @Schema(implementation=Comment.class)
			)}
		),
		@ApiResponse(
			responseCode = "404",
			description = "Book or comment not found",
			content = @Content
		)
	})
	@DeleteMapping("/{bookId}/comments/{id}")
	public ResponseEntity<Comment> deleteComment(
			@Parameter(description = "id of book where the comment belongs to") @PathVariable Long bookId,
			@Parameter(description = "id of the comment to delete") @PathVariable Long id) {
		
		Book book = this.bookService.findById(id);
		if (book == null) {
			return ResponseEntity.notFound().build();
		}
		Comment comment = this.bookService.findCommentById(bookId, id);
		if (comment == null) {
			return ResponseEntity.notFound().build();
		}
		this.bookService.deleteCommentById(bookId, id);
		return ResponseEntity.ok(comment);
	}
}
