package es.codeurjc.books.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import es.codeurjc.books.model.Book;
import es.codeurjc.books.model.Comment;
import es.codeurjc.books.service.BookService;
import es.codeurjc.books.service.UserSession;

@Controller
public class BooksWebController {
	
	@Autowired
	private BookService bookService;
	
	@Autowired
	private UserSession userSession;
	
	@GetMapping("/")
	public String showBooks(Model model) {
		model.addAttribute("books", bookService.findAll());
		return "index";
	}
	
	@GetMapping("/book/{id}")
	public String showBook(Model model, @PathVariable Long id) {
		Book book = this.bookService.findById(id);
		model.addAttribute("book", book);
		model.addAttribute("author",userSession.getUsername());
		//model.addAttribute("comments",bookService.findAllCommentsById(id));
		return "show_book";
	}
	
	@PostMapping("/book/new")
	public String newBook(Model model, Book book) {
		this.bookService.save(book);
		return "saved_book";
	}
	
	@GetMapping("/book/{id}/delete")
	public String deleteBook(Model model, @PathVariable Long id) {
		this.bookService.deleteById(id);
		return "deleted_book";
	}
	
	@PostMapping("/book/{id}/comment/new")
	public String newComment(Model model, Comment comment, @PathVariable Long id) {
		userSession.setUsername(comment.getAuthor());
		this.bookService.saveComment(comment, id);
		return "redirect:/book/"+id;
	}
	
	@PostMapping("/book/{bookId}/comment/{id}/delete")
	public String deleteComment(Model model, @PathVariable Long bookId, @PathVariable Long id) {
		this.bookService.deleteCommentById(bookId, id);
		return "redirect:/book/"+id;
	}	
}
