package es.codeurjc.books.service;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import es.codeurjc.books.model.Book;
import es.codeurjc.books.model.Comment;

@Service
public class BookService {
	
	private ConcurrentMap<Long, Book> books = new ConcurrentHashMap<>();
	private AtomicLong nextId = new AtomicLong();
	private AtomicLong nextCommentId = new AtomicLong();
	
	public BookService() {
		
		this.save(new Book(
				"Don Quijote",
				"En un lugar de la Mancha",
				"Cervantes",
				"Desconocido",
				1605));
		
		this.save(new Book(
				"El principito",
				"Un piloto se pierde en el Sáhara",
				"Antoine de Saint-Exupéry",
				"Gallimard",
				1943));
		
		this.saveComment(
				new Comment(
						"un clásico",
						5,
						"yo mismo"),
				0L);
		
		this.saveComment(
				new Comment(
						"no me ha gustado",
						0,
						"comentarista"),
				0L);
	}
	
	public Collection<Book> findAll() {
		return this.books.values();
	}
	
	public Book findById(Long id) {
		return this.books.get(id);
	}
	
	public void save(Book book) {
		Long id = this.nextId.getAndIncrement();
		book.setId(id);
		this.books.put(id, book);
	}
	
	public void deleteById(Long id) {
		this.books.remove(id);
	}
	
	public Collection<Comment> findAllCommentsById(Long id) {
		return this.books.get(id).getCommentsMap().values();
	}
	
	public void saveComment(Comment comment, Long bookId) {
		Long id = this.nextCommentId.getAndIncrement();
		comment.setId(id);
		this.books.get(bookId).getCommentsMap().put(id, comment);
	}
	
	public void deleteCommentById(Long bookId, Long id) {
		this.books.get(bookId).getCommentsMap().remove(id);
	}
	
	public Comment findCommentById(Long bookId, Long id) {
		return this.books.get(bookId).getCommentsMap().get(id);
	}
}
