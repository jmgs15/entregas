package es.codeurjc.books.model;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

public class Book {
	
	public interface Simplified {}
	
	@JsonView(Simplified.class)
	private Long id;
	
	@JsonView(Simplified.class)
	private String title;
	
	private String summary;
	private String author;
	private String publisher;
	private int year;
	
	private ConcurrentMap<Long, Comment> comments = new ConcurrentHashMap<>();
	
	public Book(String title, String summary, String author, String publisher, int year) {
		super();
		this.title = title;
		this.summary = summary;
		this.author = author;
		this.publisher = publisher;
		this.year = year;
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getSummary() {
		return summary;
	}
	
	public void setSummary(String summary) {
		this.summary = summary;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setYear(int year) {
		this.year = year;
	}
	
	@JsonIgnore
	public Map<Long, Comment> getCommentsMap() {
		return this.comments;
	}
	
	public Collection<Comment> getComments() {
		return this.comments.values();
	}
	
	@Override
	public String toString() {
		return String.format(
				"Book [id=%s, title=%s, summary=%s, author=%s, publisher=%s, year=%d",
				id,title,summary,author,publisher,year);
	}
}
