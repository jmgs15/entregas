package es.codeurjc.books.model;

public class Comment {

	private Long id;
	private String text;
	private int score;
	private String author;

	public Comment(String text, int score, String author) {
		super();
		this.text = text;
		this.score = score;
		this.author = author;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
