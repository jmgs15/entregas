package es.codeurjc.books.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import es.codeurjc.books.dtos.requests.BookRequestDto;
import es.codeurjc.books.dtos.requests.CommentRequestDto;
import es.codeurjc.books.dtos.responses.BookDetailsResponseDto;
import es.codeurjc.books.services.BookService;
import es.codeurjc.books.services.UserSession;

@Controller
public class BookWebController {

	private BookService bookService;
	private UserSession userSession;

	public BookWebController(BookService bookService, UserSession userSession) {
		this.bookService = bookService;
		this.userSession = userSession;
	}

	@GetMapping("/")
	public String getBooks(Model model) {
		model.addAttribute("books", this.bookService.findAll());

		return "index";
	}

	@GetMapping("/book/{id}")
	public String getBook(Model model, @PathVariable long id) {
		BookDetailsResponseDto bookDetailsResponseDto = this.bookService.findById(id);
		model.addAttribute("book", bookDetailsResponseDto);
		model.addAttribute("user", this.userSession.getUser());

		return "book_details";
	}

	@GetMapping("/book/new")
	public String newBookForm() {
		return "new_book";
	}

	@PostMapping("/book/new")
	public String newBook(BookRequestDto bookRequestDto) {
		this.bookService.save(bookRequestDto);

		return "redirect:/";
	}

	@PostMapping("/book/{bookId}/comment/")
	public String newComment(Model model, @PathVariable long bookId, CommentRequestDto commentRequestDto) {
		this.bookService.addComment(bookId, commentRequestDto);
		this.userSession.setUser(commentRequestDto.getUser());
		model.addAttribute("user", this.userSession.getUser());

		return "redirect:/book/" + bookId;
	}

	@PostMapping("/book/{bookId}/comment/{commentId}")
	public String deleteComment(Model model, @PathVariable long bookId, @PathVariable long commentId) {
		this.bookService.deleteComment(bookId, commentId);
		model.addAttribute("user", this.userSession.getUser());

		return "redirect:/book/" + bookId;
	}

}
