package es.codeurjc.books.repositories;

import java.util.Collection;
import java.util.Optional;

import es.codeurjc.books.models.Comment;

public interface CommentRepository {

    Collection<Comment> findByBookId(long bookId);

    Comment save(Comment comment);

    Optional<Comment> findByBookIdAndId(long bookId, long commentId);

    Comment delete(Comment comment);

}
