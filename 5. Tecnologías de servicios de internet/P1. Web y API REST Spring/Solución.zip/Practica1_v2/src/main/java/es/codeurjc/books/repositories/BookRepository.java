package es.codeurjc.books.repositories;

import java.util.Collection;
import java.util.Optional;

import es.codeurjc.books.models.Book;

public interface BookRepository {

    Collection<Book> findAll();

    Book save(Book book);

    Optional<Book> findById(long bookId);

}
