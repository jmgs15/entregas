package es.codeurjc.books.services;

import java.util.Collection;

import es.codeurjc.books.dtos.requests.BookRequestDto;
import es.codeurjc.books.dtos.requests.CommentRequestDto;
import es.codeurjc.books.dtos.responses.BookDetailsResponseDto;
import es.codeurjc.books.dtos.responses.BookResponseDto;
import es.codeurjc.books.dtos.responses.CommentResponseDto;

public interface BookService {

    Collection<BookResponseDto> findAll();

    BookDetailsResponseDto save(BookRequestDto bookRequestDto);

    BookDetailsResponseDto findById(long bookId);

    CommentResponseDto addComment(long bookId, CommentRequestDto commentRequestDto);

    CommentResponseDto deleteComment(long bookId, long commentId);
}
