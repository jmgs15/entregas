package com.urjc.toposervice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToposerviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
