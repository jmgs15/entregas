package es.codeurjc.books.dtos.responses;

import lombok.Data;

@Data
public class CommentUserResponseDto {

    private String nick;
    private String email;

}
