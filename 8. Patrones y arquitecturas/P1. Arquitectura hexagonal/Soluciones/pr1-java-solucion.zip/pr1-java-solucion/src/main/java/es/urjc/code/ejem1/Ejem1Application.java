package es.urjc.code.ejem1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejem1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejem1Application.class, args);
	}

}
