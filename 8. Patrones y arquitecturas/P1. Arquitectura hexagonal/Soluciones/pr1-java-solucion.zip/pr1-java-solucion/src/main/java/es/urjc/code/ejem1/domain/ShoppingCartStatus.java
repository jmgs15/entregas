package es.urjc.code.ejem1.domain;

public enum ShoppingCartStatus {
	PENDING, COMPLETED
}
