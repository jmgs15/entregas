/**
  * This is the app Model it is decoupled from
  * the Entities used for the databse
*/
class Shoppingcart {
  constructor(id, status, items) {
    this.id = id;
    this.status = status;
    this.items = items;
  }
}

module.exports = Shoppingcart;
