
const logging = require('../../common/logging');

function init({
  shoppingcartRepository,
  //productsRepository,
  validationService,
}) {
  async function getShoppingcart(id) {
    return shoppingcartRepository.getShoppingcart(id);
  }

  async function createShoppingcart() {
    logging.info("Creating shopping cart");
    return shoppingcartRepository.createShoppingcart();
  }

  async function addProduct({
    id,
    productId,
    quantity,
  }) {
    const shoppingcart = await shoppingcartRepository.getShoppingcart(id);
    logging.info(`Shopping cart: ${shoppingcart}`);
    if(shoppingcart.items === undefined) {
      shoppingcart.items = [{productId: productId, quantity: quantity}];
    } else {
      shoppingcart.items.push({productId: productId, quantity: quantity});
    }
    logging.info(`Updating cart: ${shoppingcart.id}`);
    return shoppingcartRepository.saveShoppingcart(shoppingcart);
  }

  async function updateShoppingcart(id) {
    const shoppingcart = await shoppingcartRepository.getShoppingcart(id);
    logging.info(`shopping cart found: ${shoppingcart._id}`);
    const ok = validationService.validate({
      items: shoppingcart.items,
    });
    if(ok) {
      shoppingcart.status = "COMPLETED";
      shoppingcartRepository.saveShoppingcart(shoppingcart);
    }
    return shoppingcart;
  }

  return {
    getShoppingcart,
    createShoppingcart,
    updateShoppingcart,
    addProduct,
  }
}

module.exports.init = init;
