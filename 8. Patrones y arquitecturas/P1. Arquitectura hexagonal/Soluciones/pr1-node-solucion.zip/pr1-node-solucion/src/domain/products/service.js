// DOMAIN LAYER
// Has the postRepository as a dependency. The PostService does not know
// nor does it care where the post models came from. This is abstracted away
// by the implementation of the repositories. It just calls the needed repositories
// gets the results and usually applies some business logic on them.
function init({
  productsRepository,
}) {
  async function listProducts() {
    return productsRepository.listProducts();
  }

  async function createProduct({
    name,
    description,
    price,
  }) {
    console.log(productsRepository);
    return productsRepository.createProduct({
      name,
      description,
      price,
    });
  }

  async function getProduct(productId) {
    return productsRepository.getProduct(productId);
  }

  async function removeProduct({
    productId,
  }) {
    return productsRepository.deleteProduct({
      productId,
    });
  }

  return {
    listProducts,
    createProduct,
    getProduct,
    removeProduct,
  };
}

module.exports.init = init;
