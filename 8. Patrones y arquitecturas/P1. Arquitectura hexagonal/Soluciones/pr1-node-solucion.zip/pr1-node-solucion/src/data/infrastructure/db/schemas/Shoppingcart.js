const logging = require('../../../../common/logging')

function create(mongoose) {
  logging.info("Creating schemas...");
  const itemSchema = mongoose.Schema({
    productId: {
      type: String,
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
    }
  });
  logging.info("itemSchema created");
  const shoppingcartSchema = mongoose.Schema({
    status: {
      type: String,
      required: true,
    },
    items: {
      type: [itemSchema],
    },
  });
  logging.info("shoppingcartSchema created");
  return mongoose.model('Shoppingcart', shoppingcartSchema);
}


module.exports = create;
