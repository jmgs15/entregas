const productSchema = require('./Product');
const shoppingcartSchema = require('./Shoppingcart');


module.exports.create = mongoose => ({
  Product: productSchema(mongoose),
  Shoppingcart: shoppingcartSchema(mongoose),
});
