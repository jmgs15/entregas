// DATA LAYER
// postRepository:
// is used to provide an abstraction on top of the database ( and possible other data sources)
// so other parts of the application are decoupled from the specific database implementation.
// Furthermore it can hide the origin of the data from it's consumers.
// It is possible to fetch the entities from different sources like inmemory cache,
// network or the db without the need to alter the consumers code.
// I am using a factory function (using object literal and prototype) to pass methods on prototype chain
// With factory functions(closures) we can have data privacy.

const errors = require('../../../common/errors');
const mapper = require('../../mapper');
const ProductDomainModel = require('../../../domain/products/model');

const productStore = {
  async listProducts(options) {
    try {
      const { Product: productSchema } = this.getSchemas();
      const docs = await productSchema.find();
      return docs;
    } catch (error) {
      throw error;
    }
  },
  async createProduct(options) {
    try {
      const { Product: productSchema } = this.getSchemas();
      const newProduct = new productSchema({
        productId: options.productId,
        name: options.name,
        description: options.description,
        price: options.price,
      });
      const doc = await newProduct.save();
      return mapper.toDomainModel(doc, ProductDomainModel);
    } catch (error) {
      throw error;
    }
  },
  async getProduct(productId) {
    try {
      const { Product: productSchema } = this.getSchemas();
      const doc = await productSchema.findById(productId).lean().exec();
      if (!doc) {
        throw new errors.NotFound(`Product with id ${productId} not found.`);
      }
      return mapper.toDomainModel(doc, ProductDomainModel);
    } catch (error) {
      throw error;
    }
  },
  async deleteProduct(options) {
    try {
      const { Product: productSchema } = this.getSchemas();
      const doc = await productSchema.delete({ _id: options.productId }).lean().exec();
      if (!doc) {
        throw new errors.NotFound(`Product with id ${options.productId} not found.`);
      }
      return mapper.toDomainModel(doc, ProductDomainModel);
    } catch(error) {
      throw error;
    }
  },
};


module.exports.init = ({ Product }) => Object.assign(Object.create(productStore), {
  getSchemas() {
    return {
      Product,
    };
  },
});

