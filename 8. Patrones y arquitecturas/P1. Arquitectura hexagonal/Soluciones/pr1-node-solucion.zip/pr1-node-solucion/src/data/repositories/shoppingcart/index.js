const errors = require('../../../common/errors');
const logging = require('../../../common/logging');
const mapper = require('../../mapper');
const ShoppingcartDomainModel = require('../../../domain/shoppingcart/model');

const shoppingcartStore = {
  async createShoppingcart() {
    try {
      const { Shoppingcart: shoppingcartSchema } = this.getSchemas();
      logging.info("Schemas created");
      const newShoppingcart = new shoppingcartSchema({
        status: "PENDING",
        items: [],
      });
      logging.info("Shopping cart etity created");
      const shoppingcartDoc = await newShoppingcart.save();
      logging.info("Shopping cart entity saved");
      return mapper.toDomainModel(shoppingcartDoc, ShoppingcartDomainModel);
    } catch (error) {
      logging.info(error);
      throw error;
    }
  },

  async getShoppingcart(id) {
    try {
      const { Shoppingcart: shoppingcartSchema } = this.getSchemas();
      const shoppingcartDoc = await shoppingcartSchema.findById(id).lean().exec();
      if (!shoppingcartDoc) {
        throw new errors.NotFound('Shopping cart not found.');
      }
      logging.info(`Items: ${shoppingcartDoc.items}`);
      return mapper.toDomainModel(shoppingcartDoc, ShoppingcartDomainModel);
    } catch (error) {
      throw error;
    }
  },

  async saveShoppingcart(shoppingcart) {
    logging.info(`Looking up shopping cart: ${shoppingcart.id}`);
    const { Shoppingcart: shoppingcartSchema } = this.getSchemas();
    const shoppingcartDoc = await shoppingcartSchema.findByIdAndUpdate(shoppingcart.id, {items: shoppingcart.items}).exec();
    logging.info(`Cart after being saved: ${shoppingcartDoc._id}`);
    return mapper.toDomainModel(shoppingcartDoc, ShoppingcartDomainModel);
  }
};

module.exports.init = function init({ Shoppingcart }) {
  return Object.assign(Object.create(shoppingcartStore), {
    getSchemas() {
      return {
        Shoppingcart,
      };
    },
  });
};
