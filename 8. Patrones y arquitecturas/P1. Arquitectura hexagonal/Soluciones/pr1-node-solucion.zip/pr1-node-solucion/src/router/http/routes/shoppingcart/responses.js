/**
  * This is the shoppingcart response.
  * Added in order to avoid return Products as response.
  * Products is property of our business model in domain layer.
*/
class ShoppingcartResponse {
  constructor({ id, status, items } = {}) {
    this.id = id;
    this.status = status;
    this.items = items;
  }
}

module.exports = ShoppingcartResponse;
