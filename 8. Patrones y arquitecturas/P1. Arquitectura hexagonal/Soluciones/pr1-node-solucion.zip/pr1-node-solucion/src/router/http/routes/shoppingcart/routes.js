const express = require('express');
const logging = require('../../../../common/logging');
const asyncWrapper = require('../../utils/asyncWrapper');
const {
  toResponseModel,
} = require('../shoppingcart/mapper');

const router = express.Router({ mergeParams: true });

function init({ shoppingcartService, }) {
  router.get('/api/shoppingcart/:id',
    asyncWrapper(async (req, res) => {
      const result = await shoppingcartService.getShoppingcart(req.params.id);
      return res.send({
        data: Object.assign({},
          { status: result.status,
          id: result.id,
          items: result.items }),
      });
    }));
  router.post('/api/shoppingcart/:id/product/:productId/quantity/:quantityId', 
    asyncWrapper(async (req, res) => {
      const result = await shoppingcartService.addProduct({
        id: req.params.id,
        productId: req.params.productId,
        quantity: req.params.quantity,
      });
      return res.send({
        data: Object.assign({},
          {status: result.status,
          id: result.id,
          items: result.items}),
      });
    }));

  router.post('/api/shoppingcart',
    asyncWrapper(async (req, res) => {
      logging.info("Create shopping cart");
      const result = await shoppingcartService.createShoppingcart();
      return res.send({
        data: Object.assign({},
          toResponseModel(result.items),
          {status: result.status,
          id: result.id}),
      });      
    }));

  router.patch('/api/shoppingcart/:id', 
    asyncWrapper(async (req, res) => {
      const result = await shoppingcartService.updateShoppingcart(req.params.id);
      return res.send({
        data: Object.assign({},
          toResponseModel(result.items),
          {status: result.status,
          items: result.items}),
      });      
    }));

  return router;
}

module.exports.init = init;
