const ShoppingcartResponse = require('./responses');

const toResponseModel = function toResponseModel(shoppingcartDoc) {
  return new ShoppingcartResponse({ ...shoppingcartDoc });
};


module.exports = {
  toResponseModel,
};
