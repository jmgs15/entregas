const express = require('express');
const asyncWrapper = require('../../utils/asyncWrapper');

const router = express.Router({ mergeParams: true });


function init({
  productsService,
}) {

  router.get('/api/product', asyncWrapper(async (req, res) => {
    const productsList = await productsService.listProducts();
    return res.send(productsList);
  }));

  router.post('/api/product', asyncWrapper(async (req, res) => {
    const newPost = await productsService.createProduct({
      name: req.body.name,
      description: req.body.description,
      price: req.body.price,
    });
    return res.send({
      data: newPost,
    });
  }));

  router.get('/api/product/:productId', asyncWrapper(async (req, res) => {
    const productDoc = await productsService.getProduct(req.params.productId);
    return res.send({
      data: productDoc,
    });
  }));

  router.delete('/api/product/:productId', asyncWrapper(async (req, res) =>{
    const productDoc = await productsService.removeProduct({
      productId: req.params.productId,
    });
    return res.send({
      data: productDoc,
    });
  }));

  return router;
}


module.exports.init = init;
