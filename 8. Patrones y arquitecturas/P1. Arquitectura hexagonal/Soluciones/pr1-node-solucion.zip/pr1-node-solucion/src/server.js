const {
  httpPort,
  dbConnectionString,
} = require('./configuration');
const logging = require('./common/logging');
const signals = require('./signals');
const db = require('./data/infrastructure/db')({ dbConnectionString });
const productsRepositoryContainer = require('./data/repositories/products');
const shoppingcartRepositoryContainer = require('./data/repositories/shoppingcart');
const validationServiceContainer = require('./data/infrastructure/validation');
const productsServiceContainer = require('./domain/products/service');
const shoppingcartServiceContainer = require('./domain/shoppingcart/service');
const appContainer = require('./router/http/app');

const productsRepository = productsRepositoryContainer.init(db.schemas);
const shoppingcartRepository = shoppingcartRepositoryContainer.init(db.schemas);

const validationService = validationServiceContainer.init();

const productsService = productsServiceContainer.init({
  productsRepository,
});
const shoppingcartService = shoppingcartServiceContainer.init({
  shoppingcartRepository,
  validationService,
});
const app = appContainer.init({
  productsService,
  shoppingcartService,
});

let server;

// to setup server configurations and share port address for incoming requests
server = app.listen(httpPort, () => {
  logging.info(`Listening on *:${httpPort}`);
});


const shutdown = signals.init(async () => {
  await db.close();
  await server.close();
});

(async () => {
  try {
    await db.connect();
  } catch (error) {
    await shutdown();
  }
})();

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
