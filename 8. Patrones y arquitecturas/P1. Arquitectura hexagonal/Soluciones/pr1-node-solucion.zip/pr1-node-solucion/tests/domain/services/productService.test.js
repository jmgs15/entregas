const productService = require('../../../src/domain/products/service.js');

let service;
let product = { id: "1", name: "P1", description: "A product", price: 10.5 };

beforeEach(() => {
    const createProduct = jest.fn().mockResolvedValue(product);
    const deleteProduct = jest.fn().mockResolvedValue(product);

    let productsRepository = {
        createProduct,
        deleteProduct
    };

    service = productService.init({
        productsRepository,
    });
});

test('product can be added', async () => {
    const productCreated = await service.createProduct({ name: "P1", description: "A product", price: 10.5 });
    expect(productCreated.id).toBe("1");
});

test('product can be deleted', async () => {
    const productDeleted = await service.removeProduct({ productId: product.id });
    expect(productDeleted.id).toBe("1");
});
