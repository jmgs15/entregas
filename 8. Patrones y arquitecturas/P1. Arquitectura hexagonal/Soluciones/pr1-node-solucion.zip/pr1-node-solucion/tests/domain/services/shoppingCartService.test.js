const productService = require('../../../src/domain/shoppingcart/service.js');

let service;
let shoppingCart = { id: "1", status: "PENDING", items: [] };
let product = { id: "1", name: "P1", description: "A product", price: 10.5 };
let shoppingCartWithProduct = { id: "1", status: "PENDING", items: [product] };

beforeEach(() => {
    const createShoppingcart = jest.fn().mockResolvedValue(shoppingCart);
    const getShoppingcart = jest.fn().mockResolvedValue(shoppingCart);
    const saveShoppingcart = jest.fn().mockResolvedValue(shoppingCartWithProduct);

    let shoppingcartRepository = {
        createShoppingcart,
        getShoppingcart,
        saveShoppingcart
    };

    service = productService.init({
        shoppingcartRepository,
    });
});

test('shopping cart can be added', async () => {
    const shoppingCartCreated = await service.createShoppingcart();
    expect(shoppingCartCreated.id).toBe("1");
});

test('product can be added to shopping cart', async () => {
    const shoppingCartAddedProduct = await service.addProduct({ id: 1, productId: 1, quantity: 1 });
    expect(shoppingCartAddedProduct.items.length).toBe(1);
});
