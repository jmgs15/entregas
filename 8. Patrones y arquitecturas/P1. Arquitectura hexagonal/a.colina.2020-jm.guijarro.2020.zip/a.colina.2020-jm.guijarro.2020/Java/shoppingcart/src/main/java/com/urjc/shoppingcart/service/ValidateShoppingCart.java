package com.urjc.shoppingcart.service;

public class ValidateShoppingCart {
    int id;

    public ValidateShoppingCart(int id) {
        this.id = id;
    }

    public ValidateShoppingCart() {
    }

    public int getId() {
        return this.id;
    }
}
