package com.urjc.shoppingcart.domain.model;

public enum CartStatus {
    CREATED,
    INPROGRESS,
    FINISHED
}
