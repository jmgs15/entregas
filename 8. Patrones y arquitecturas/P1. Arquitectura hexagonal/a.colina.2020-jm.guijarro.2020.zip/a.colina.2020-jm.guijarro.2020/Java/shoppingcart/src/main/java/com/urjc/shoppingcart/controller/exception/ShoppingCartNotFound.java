package com.urjc.shoppingcart.controller.exception;

public class ShoppingCartNotFound extends Exception {
}
