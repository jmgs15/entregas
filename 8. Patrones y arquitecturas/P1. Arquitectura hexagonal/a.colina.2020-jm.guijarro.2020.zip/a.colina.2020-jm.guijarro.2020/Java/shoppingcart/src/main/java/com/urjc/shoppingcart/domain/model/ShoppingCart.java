package com.urjc.shoppingcart.domain.model;

import java.util.List;

public class ShoppingCart {
    List<Product> products;
    CartStatus status;
}
