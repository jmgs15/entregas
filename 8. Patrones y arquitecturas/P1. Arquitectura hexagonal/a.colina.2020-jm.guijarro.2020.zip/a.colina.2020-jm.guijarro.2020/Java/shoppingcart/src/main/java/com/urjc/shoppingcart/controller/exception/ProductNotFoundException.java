package com.urjc.shoppingcart.controller.exception;


public class ProductNotFoundException extends Exception {
}
