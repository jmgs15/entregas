package com.urjc.shoppingcartvalidator.domain;

public class ValidatorException extends Exception {
    public ValidatorException(Exception ex) {
    }
}
