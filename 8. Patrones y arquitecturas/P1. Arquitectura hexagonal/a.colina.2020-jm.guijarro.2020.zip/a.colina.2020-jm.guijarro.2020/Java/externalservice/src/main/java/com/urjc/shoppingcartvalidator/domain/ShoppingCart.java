package com.urjc.shoppingcartvalidator.domain;

public class ShoppingCart {
    private int id;

    public ShoppingCart(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }
}
