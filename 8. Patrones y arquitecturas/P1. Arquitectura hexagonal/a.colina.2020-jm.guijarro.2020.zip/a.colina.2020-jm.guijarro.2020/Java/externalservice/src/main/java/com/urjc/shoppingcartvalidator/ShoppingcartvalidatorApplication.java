package com.urjc.shoppingcartvalidator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingcartvalidatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingcartvalidatorApplication.class, args);
	}

}
