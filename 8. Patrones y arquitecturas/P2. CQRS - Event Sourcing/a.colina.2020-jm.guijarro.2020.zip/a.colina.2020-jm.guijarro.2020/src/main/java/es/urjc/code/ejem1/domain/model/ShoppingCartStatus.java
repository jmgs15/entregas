package es.urjc.code.ejem1.domain.model;

public enum ShoppingCartStatus {
	PENDING, COMPLETED
}
